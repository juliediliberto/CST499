import React from 'react';

class LoadingRoute extends React.Component {

  render(){
    return (
      <div className="loading-page"></div>
    )
  }
}

export default LoadingRoute;
